// call all the required packages
var express = require('express');
// var Request = require('request');
var bodyParser = require('body-parser');
var multer = require('multer');
// var fs = require('fs');
var WatsonClient = require('./WatsonAPI/WatsonCall');
var port = '3000';
// var ClientProcess = require('./ClientProcess');
// var ProcessPort = '3000';
// var ProcessUrl = '10.1.126.49';

var app = express();
app.use(bodyParser.urlencoded({ extended: true }))


// SET STORAGE
var storage = multer.memoryStorage();
var upload = multer({ storage: storage});

//ROUTES WILL GO HERE
app.get('/', function (req, res) {
    res.sendFile(__dirname + '/index.html');
});

app.post('/upload/photo', upload.single('myImage'), (req, res) => {
    var file = req.file.buffer;
    Response = new Object;

    WatsonClient(file);

    res.send (200 + ' OK!');
});
    

app.listen(port, () => console.log(('Server started on port %d'), port));