ClientProcess = function ClientProcess(ProcessUrl, frontImage, ProcessPort, res) { 

    var http = require("http");
    //if (FrontImage = null) {var FrontImage = { class: 'clock', score: 0.678 }};
    //if (ProcessPort = null) {var ProcessPort = '3000'}; 
    //if (ProcessUrl = null) {var ProcessUrl = 'http://10.1.127.46'};
    var options = {
        "method": "POST",
        "hostname": ProcessUrl,
        "port": ProcessPort,
        "path": [
          "/front"
        ],
        "headers": {
          "Content-Type": "multipart/form-data",
          "cache-control": "no-cache",
        }
      };
      var req = http.request(options, function (res) {
      var chunks = [];
  
      res.on("data", function (chunk) {
        chunks.push(chunk);
      });
  
      res.on("end", function () {
        var body = Buffer.concat(chunks);
        console.log(body.toString());
      });
    });
  
    req.write(frontImage);
    req.end();
  }
  module.exports = ClientProcess