var WatsonClient = require('./WatsonCall')
WatsonClient()